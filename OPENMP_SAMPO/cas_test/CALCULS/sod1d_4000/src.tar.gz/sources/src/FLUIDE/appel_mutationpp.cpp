#ifdef MPP_ACTIF
// Must include this header file to use the Mutation++ library
#include "mutation++.h"
#include <iostream>

using namespace Mutation;
using namespace Mutation::Thermodynamics;
#endif

//double* p_work_species;
//double* p_work_element;

extern "C"
void mpp_initialisation(const char *liste_especes, const char *stateModel, const char *database, struct Mixture** pp_mix)
{
#ifdef MPP_ACTIF

  // Genere les options par defaut
  Mutation::MixtureOptions opts;
  // liste des especes  
  opts.setSpeciesDescriptor(liste_especes);
  // on va faire le calcul de l'equilibre a partir de p et T
  opts.setStateModel(stateModel);
  // Choix de la base de donnee (base de donnée thermodynamique RRHO ou polynomes NASA-9)
  opts.setThermodynamicDatabase(database);
  
  Mixture* p_mix = new Mutation::Mixture(opts);
  *pp_mix = p_mix;

  // p_work_species = new double [p_mix->nSpecies()];
  // p_work_element = new double [p_mix->nElements()];
#endif
}

// calcul equilibre a partir de la pression et la temperature
extern "C"
void mpp_equilibre_from_pTxele(struct Mixture* p_mix, double P, double T, 
			       const char *compo_elements,int nbe,int permut[],double x_especes[])
{
#ifdef MPP_ACTIF
  // Composition en elements
  p_mix->addComposition(compo_elements, true);
  
  // Set the mixture state equal to the equilibrium state for the given
  // temperature and pressure
  p_mix->setState(&P, &T, 1);
  
  // Species mole fractions
  int k;
  for (int i = 0; i < p_mix->nSpecies(); ++i){
    k = permut[i];
    x_especes[k] = p_mix->X()[i];
  }
#endif
}

// calcul de l'equilibre a partir de la densite et de l'energie interne*rho
// Renvoie la composition en especes à l'equilibre
// la temperature et la pression
extern "C"
void mpp_equilibre_from_rho_eps(struct Mixture* p_mix, double rho, double rhoeps, 
				const char *compo_elements,int nbe,int permut[],
				double x_especes[], double& p, double& T)
{
#ifdef MPP_ACTIF
  // Composition en elements
  p_mix->addComposition(compo_elements, true);

  rhoeps=(rhoeps/rho-84588.1)*rho;

  // Set the mixture state equal to the equilibrium state for the given
  // temperature and pressure
  p_mix->setState(&rho, &rhoeps, 0);
  
  // Species mole fractions
  int k;
  for (int i = 0; i < p_mix->nSpecies(); ++i){
    k = permut[i];
    x_especes[k] = p_mix->X()[i];
  }
  
  // on recupere la pression et la temperature
  p = p_mix->P();
  T = p_mix->T();
#endif
}

// calcul des derivées de la fraction molaire par rapport à la température
extern "C"
void mpp_dxdT(struct Mixture* p_mix, int nbe, int permut[], double dxdT[])
{
#ifdef MPP_ACTIF
  double tmp[nbe];
  p_mix->dXidT(tmp);
  int k;
  for (int i = 0; i < p_mix->nSpecies(); ++i){
    k = permut[i];
    dxdT[k] = tmp[i];
  }
#endif
}

// calcul des derivées de la fraction molaire par rapport à la pression
extern "C"
void mpp_dxdP(struct Mixture* p_mix, int nbe, int permut[], double dxdP[])
{
#ifdef MPP_ACTIF
  double tmp[nbe];
  p_mix->dXidP(tmp);
  int k;
  for (int i = 0; i < p_mix->nSpecies(); ++i){
    k = permut[i];
    dxdP[k] = tmp[i];
  }
#endif
}

// calcul de l'énergie interne, on rajoute +10000 car mutation ++ peut donner des énergies négatives sans ça
extern "C"
void mpp_energie_interne(struct Mixture* p_mix, double& eps)
{
#ifdef MPP_ACTIF
  //eps = p_mix->mixtureEnergyMass(); 
  eps = p_mix->mixtureEnergyMass()+84588.1;
#endif
}

// calcul de la vitesse du son
extern "C"
void mpp_vitesse_du_son_equilibre(struct Mixture* p_mix, double& c)
{
#ifdef MPP_ACTIF
  c = p_mix->equilibriumSoundSpeed();
#endif
}

// calcul de la masse volumique
extern "C"
void mpp_densite(struct Mixture* p_mix, double& rho)
{
#ifdef MPP_ACTIF
  rho = p_mix->density(); 
#endif
}

// calcul de la dérivée de la masse volumique par rapport à la pression
extern "C"
void mpp_drhodp(struct Mixture* p_mix, double& drhodp)
{
#ifdef MPP_ACTIF
  drhodp = p_mix->dRhodP(); 
#endif
}

//calcul de mu, le coefficient de viscosite
extern "C"
void mpp_mu(struct Mixture* p_mix, double& mu)
{
#ifdef MPP_ACTIF
  mu=p_mix->viscosity();
#endif
}

//calcul de l'enthalpie spécifique
extern "C"
void mpp_Hf(struct Mixture* p_mix, double& Hf, double T, bool Kg)
{
#ifdef MPP_ACTIF
  double* species_values = new double[p_mix->nSpecies()];
  double* temp           = new double[std::max(p_mix->nSpecies(), p_mix->nElements()*p_mix->nElements())];

  p_mix->speciesHOverRT(temp,NULL,NULL,NULL,NULL, species_values);
  Hf=0.0;
  for (int i = 0; i < p_mix->nSpecies(); ++i)
    Hf += species_values[i] * RU * T * p_mix->X()[i];  //RU est une constante donnée par mutation au travers du header
  //le résultat est ici en J/mol

  if(Kg){
    Hf /= p_mix->mixtureMw();
  }

  delete [] species_values;
  delete [] temp;
#endif
}

//calcul de l'enthalpie spécifique pour une espèce
extern "C"
void mpp_Hf_esp(struct Mixture* p_mix, double& Hf, double T, int esp, int nb, int permut[])
{
#ifdef MPP_ACTIF
  double* species_values = new double[p_mix->nSpecies()];
  double* temp           = new double[std::max(p_mix->nSpecies(), p_mix->nElements()*p_mix->nElements())];
  int i = permut[esp-1]; // le C commence a 0...
    
  p_mix->speciesHOverRT(temp,NULL,NULL,NULL,NULL, species_values);
  Hf=0.0;
  Hf= species_values[i] * RU * T * p_mix->X()[i];  //RU est une constante donnée par mutation au travers du header
  //le résultat est ici en J/mol
  //on le traduit donc en J/KG
  Hf/=p_mix->speciesMw()[i];

  delete [] species_values;
  delete [] temp;
#endif
}

//calcul de Cp 
extern "C"
void mpp_Cp(struct Mixture* p_mix, double& Cp)
{
#ifdef MPP_ACTIF
  Cp=p_mix->mixtureEquilibriumCpMass();
#endif
}

//calcul de Cv
extern "C"
void mpp_Cv(struct Mixture* p_mix, double& Cv)
{
#ifdef MPP_ACTIF
  Cv=p_mix->mixtureEquilibriumCvMass();
#endif
}

//calcul de K conductivit thermique
extern "C"
void mpp_K(struct Mixture* p_mix, double& K)
{
#ifdef MPP_ACTIF
  K=p_mix->equilibriumThermalConductivity();
#endif
}

/*extern "C"
void mpp_element_potential(struct Mixture* p_mix, const int nb, double lambda[])
{
  //double* p_work_species = new double [p_mix->nSpecies()];
  p_mix->elementPotentials(p_work_species);
  for (int k = 0; k < nb; ++k)
    lambda[k] = p_work_species[k];
  //delete [] p_work_species;
}
*/

//extern "C"
// void mpp_destroy(struct Mixture* p_mix)
// {
//   delete p_mix;
//   delete [] p_work_species;
//   //delete [] p_work_element;
    
//   p_mix = NULL;
//   p_work_species = NULL;
//   //p_work_element = NULL;

// }

// Dans mutation, les especes sont reordonnees
// Il faut définir la permutation pour recuperer l'ordre des especes
extern "C"
void mpp_permutations_especes(struct Mixture* p_mix, char *liste_especes, int nb_esp, int permut[])
{
#ifdef MPP_ACTIF
  // on travaille sur une copie de liste_especes car strtok modifie la chaine de caractere
  char tmp[strlen(liste_especes)]; 
  strcpy(tmp,liste_especes); 
  
  char *nom; 
  const char* nom_mpp = NULL;
  
  int i=0;
  nom = strtok(tmp," ");
  
  while(nom){
    for (int j = 0; j < p_mix->nSpecies(); ++j) 
      {
	nom_mpp = p_mix->speciesName(j).c_str();
	if (strcmp(nom,nom_mpp) == 0) {
	  permut[j] = i;
	  break;
	}
      }  
    i +=1;
    nom = strtok(NULL," ");
  }
#endif
}
